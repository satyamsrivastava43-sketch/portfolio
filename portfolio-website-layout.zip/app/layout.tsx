import React from "react"
import type { Metadata, Viewport } from 'next'
import { Inter, JetBrains_Mono } from 'next/font/google'

import './globals.css'

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
})

const jetbrainsMono = JetBrains_Mono({ 
  subsets: ['latin'],
  variable: '--font-mono',
})

export const metadata: Metadata = {
  title: 'Satyam Srivastava | Full-Stack Developer',
  description: 'B.Sc. Mathematics graduate and Full-Stack Developer passionate about building reliable, scalable web applications. Experienced with React, Node.js, and modern web technologies.',
  keywords: ['Full-Stack Developer', 'React Developer', 'Software Engineer', 'Web Developer', 'JavaScript', 'Node.js'],
  authors: [{ name: 'Satyam Srivastava' }],
  openGraph: {
    title: 'Satyam Srivastava | Full-Stack Developer',
    description: 'B.Sc. Mathematics graduate and Full-Stack Developer passionate about building reliable, scalable web applications.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  themeColor: '#0f1419',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${jetbrainsMono.variable}`}>
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
