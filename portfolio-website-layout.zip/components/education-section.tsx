import { GraduationCap, BookOpen, Calculator, TrendingUp } from "lucide-react"

const relevantSkills = [
  {
    icon: Calculator,
    title: "Mathematical Analysis",
    description: "Strong foundation in calculus, algebra, and mathematical reasoning.",
  },
  {
    icon: TrendingUp,
    title: "Statistics & Probability",
    description: "Understanding of statistical methods and data analysis techniques.",
  },
  {
    icon: BookOpen,
    title: "Logical Thinking",
    description: "Ability to break down complex problems into manageable steps.",
  },
]

export function EducationSection() {
  return (
    <section id="education" className="py-24 px-6 bg-card/50">
      <div className="mx-auto max-w-6xl">
        <div className="flex items-center gap-4 mb-12">
          <div className="h-px flex-1 bg-border" />
          <h2 className="text-3xl font-bold text-foreground">Education</h2>
          <div className="h-px flex-1 bg-border" />
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div className="p-8 bg-background rounded-lg border border-border">
            <div className="flex items-start gap-4 mb-6">
              <div className="p-3 bg-primary/10 rounded-lg">
                <GraduationCap className="h-8 w-8 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-foreground">
                  B.Sc. Mathematics
                </h3>
                <p className="text-muted-foreground">Bachelor of Science</p>
              </div>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              Emphasis on analytical reasoning, statistics, and problem-solving 
              skills applicable to software development. The rigorous mathematical 
              training provides a strong foundation for algorithmic thinking and 
              logical problem decomposition.
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-foreground mb-4">
              Relevant Skills Developed
            </h4>
            {relevantSkills.map((skill) => (
              <div
                key={skill.title}
                className="p-4 bg-background rounded-lg border border-border hover:border-primary/50 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <skill.icon className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <h5 className="font-medium text-foreground text-sm">
                      {skill.title}
                    </h5>
                    <p className="text-xs text-muted-foreground mt-1">
                      {skill.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
