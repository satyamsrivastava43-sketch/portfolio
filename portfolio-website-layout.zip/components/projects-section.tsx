import { Github, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"

const projects = [
  {
    title: "Portfolio Website",
    description: "Personal responsive portfolio built using React and modern UI practices. Focus on clean design, accessibility, and performance.",
    tech: ["React", "Tailwind CSS", "Next.js"],
    github: "https://github.com",
    live: "#",
  },
  {
    title: "Student Utility Web App",
    description: "Simple web app to manage student data or notes. CRUD functionality with basic backend integration.",
    tech: ["React", "Node.js", "MongoDB"],
    github: "https://github.com",
  },
  {
    title: "Resume Analyzer",
    description: "Frontend interface for resume analysis using AI APIs. Focus on UI, form handling, and API interaction.",
    tech: ["React", "REST API", "Tailwind CSS"],
    github: "https://github.com",
    badge: "Concept Project",
  },
]

export function ProjectsSection() {
  return (
    <section id="projects" className="py-24 px-6">
      <div className="mx-auto max-w-6xl">
        <div className="flex items-center gap-4 mb-4">
          <div className="h-px flex-1 bg-border" />
          <h2 className="text-3xl font-bold text-foreground">Projects</h2>
          <div className="h-px flex-1 bg-border" />
        </div>

        <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
          A selection of projects I&apos;ve built to solve problems and explore new technologies.
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <article
              key={project.title}
              className="group flex flex-col bg-card rounded-lg border border-border hover:border-primary/50 transition-all duration-300 overflow-hidden"
            >
              <div className="h-40 bg-gradient-to-br from-primary/10 via-secondary to-emerald-500/10 flex items-center justify-center relative">
                <div className="text-4xl font-bold text-primary/30">
                  {project.title.split(" ").map((word) => word[0]).join("")}
                </div>
                {project.badge && (
                  <span className="absolute top-3 right-3 text-xs px-2 py-1 bg-primary/20 text-primary rounded-full">
                    {project.badge}
                  </span>
                )}
              </div>
              <div className="flex flex-col flex-1 p-6">
                <h3 className="text-lg font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4 flex-1">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tech.map((tech) => (
                    <span
                      key={tech}
                      className="text-xs px-2 py-1 bg-secondary rounded-md text-muted-foreground font-mono"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                <div className="flex items-center gap-3 pt-2 border-t border-border">
                  <Button
                    variant="ghost"
                    size="sm"
                    asChild
                    className="text-muted-foreground hover:text-primary"
                  >
                    <a
                      href={project.github}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Github className="h-4 w-4 mr-2" />
                      Code
                    </a>
                  </Button>
                  {project.live && (
                    <Button
                      variant="ghost"
                      size="sm"
                      asChild
                      className="text-muted-foreground hover:text-primary"
                    >
                      <a
                        href={project.live}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Demo
                      </a>
                    </Button>
                  )}
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
