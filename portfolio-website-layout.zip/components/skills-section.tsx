import { 
  FileCode2, 
  Server, 
  Database, 
  Wrench, 
  Lightbulb 
} from "lucide-react"

const skillCategories = [
  {
    title: "Frontend",
    icon: FileCode2,
    skills: [
      { name: "HTML5", level: "Proficient" },
      { name: "CSS3", level: "Proficient" },
      { name: "JavaScript (ES6+)", level: "Proficient" },
      { name: "React", level: "Proficient" },
    ],
  },
  {
    title: "Backend",
    icon: Server,
    badge: "Learning",
    skills: [
      { name: "Node.js", level: "Basic" },
      { name: "Express", level: "Basic" },
    ],
  },
  {
    title: "Database",
    icon: Database,
    badge: "Basic",
    skills: [
      { name: "MongoDB", level: "Basic" },
    ],
  },
  {
    title: "Tools",
    icon: Wrench,
    skills: [
      { name: "Git", level: "Proficient" },
      { name: "GitHub", level: "Proficient" },
      { name: "VS Code", level: "Proficient" },
    ],
  },
  {
    title: "Other",
    icon: Lightbulb,
    skills: [
      { name: "Problem Solving", level: "Strong" },
      { name: "Data Structures", level: "Basic" },
      { name: "Mathematics & Logic", level: "Strong" },
    ],
  },
]

export function SkillsSection() {
  return (
    <section id="skills" className="py-24 px-6 bg-card/50">
      <div className="mx-auto max-w-6xl">
        <div className="flex items-center gap-4 mb-12">
          <div className="h-px flex-1 bg-border" />
          <h2 className="text-3xl font-bold text-foreground">Skills</h2>
          <div className="h-px flex-1 bg-border" />
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {skillCategories.map((category) => (
            <div
              key={category.title}
              className="group p-6 bg-background rounded-lg border border-border hover:border-primary/50 transition-all duration-300"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                    <category.icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground">{category.title}</h3>
                </div>
                {category.badge && (
                  <span className="text-xs px-2 py-1 bg-secondary rounded-full text-muted-foreground">
                    {category.badge}
                  </span>
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill) => (
                  <span
                    key={skill.name}
                    className="text-sm px-3 py-1.5 bg-secondary rounded-md text-foreground hover:bg-primary/10 hover:text-primary transition-colors cursor-default"
                    title={skill.level}
                  >
                    {skill.name}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
