import { Code2, Brain, Rocket } from "lucide-react"

const highlights = [
  {
    icon: Brain,
    title: "Analytical Mindset",
    description: "Mathematics background providing strong logical reasoning and problem-solving capabilities.",
  },
  {
    icon: Code2,
    title: "Clean Code",
    description: "Focus on writing maintainable, readable, and well-structured code following best practices.",
  },
  {
    icon: Rocket,
    title: "Continuous Learning",
    description: "Actively expanding full-stack and cloud skills to build more comprehensive solutions.",
  },
]

export function AboutSection() {
  return (
    <section id="about" className="py-24 px-6">
      <div className="mx-auto max-w-6xl">
        <div className="flex items-center gap-4 mb-12">
          <div className="h-px flex-1 bg-border" />
          <h2 className="text-3xl font-bold text-foreground">About Me</h2>
          <div className="h-px flex-1 bg-border" />
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <div className="space-y-6">
            <p className="text-lg text-muted-foreground leading-relaxed">
              B.Sc. Mathematics graduate with a strong foundation in analytical thinking 
              and problem-solving. Passionate about software development and building 
              reliable, scalable web applications.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Experienced with modern frontend technologies and actively expanding 
              full-stack and cloud skills. Focused on writing clean code and solving 
              real-world problems.
            </p>
            <div className="pt-4">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-secondary rounded-full">
                <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                <span className="text-sm text-muted-foreground">
                  Open to opportunities &amp; collaborations
                </span>
              </div>
            </div>
          </div>

          <div className="grid gap-6">
            {highlights.map((item) => (
              <div
                key={item.title}
                className="group p-6 bg-card rounded-lg border border-border hover:border-primary/50 transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                    <item.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
