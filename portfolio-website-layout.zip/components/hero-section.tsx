"use client"

import { Github, Linkedin, Mail, MapPin, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="min-h-screen flex flex-col justify-center relative px-6 pt-20">
      <div className="mx-auto max-w-6xl w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="space-y-2">
              <p className="text-primary font-mono text-sm tracking-wider uppercase">
                Hello, I&apos;m
              </p>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight text-balance">
                Satyam Srivastava
              </h1>
              <p className="text-xl sm:text-2xl text-muted-foreground font-medium">
                Full-Stack Developer &amp; Problem Solver
              </p>
            </div>

            <p className="text-muted-foreground leading-relaxed max-w-xl">
              B.Sc. Mathematics graduate with a strong foundation in analytical thinking 
              and problem-solving. Passionate about software development and building 
              reliable, scalable web applications.
            </p>

            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <MapPin className="h-4 w-4 text-primary" />
              <span>India</span>
            </div>

            <div className="flex flex-wrap gap-4 pt-4">
              <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
                <a href="#contact">Get in Touch</a>
              </Button>
              <Button variant="outline" asChild className="border-border text-foreground hover:bg-secondary bg-transparent">
                <a href="#projects">View Projects</a>
              </Button>
            </div>

            <div className="flex items-center gap-4 pt-4">
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors"
                aria-label="GitHub"
              >
                <Github className="h-5 w-5" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="h-5 w-5" />
              </a>
              <a
                href="mailto:contact@email.com"
                className="text-muted-foreground hover:text-primary transition-colors"
                aria-label="Email"
              >
                <Mail className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div className="hidden lg:flex justify-center items-center">
            <div className="relative">
              <div className="w-72 h-72 rounded-full bg-gradient-to-br from-primary/20 to-emerald-500/10 flex items-center justify-center">
                <div className="w-60 h-60 rounded-full bg-gradient-to-br from-primary/30 to-emerald-500/20 flex items-center justify-center">
                  <div className="w-48 h-48 rounded-full bg-secondary flex items-center justify-center">
                    <span className="text-6xl font-bold text-primary">SS</span>
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 w-20 h-20 bg-primary/10 rounded-lg rotate-12" />
              <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-emerald-500/10 rounded-full" />
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <a href="#about" aria-label="Scroll to about section">
          <ChevronDown className="h-6 w-6 text-muted-foreground" />
        </a>
      </div>
    </section>
  )
}
